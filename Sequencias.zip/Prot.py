class Prot():
  def __init__(self, sequencia, AAs):
   self.sequencia =sequencia
   self.AAs =AAs
   

  def contem(AAs,sequencia):
   if AAs in sequencia:
    print("A string de aminoácidos '",AAs,"' está presente na sequência.")
   else:
    print("A string de aminoácidos '",AAs,"' não está presente na sequência.")