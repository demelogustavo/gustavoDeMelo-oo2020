palmeiras = 'ACGATACGTACGTTGAT'


##fazer construtor
##restringir a contagem
##dados como atributos da classe
class Seq():
    def __init___(self, sequencia):
        self.sequencia

    def freq():
        a = 0
        c = 0
        g = 0
        t = 0
        f = open('Ebola_Virus.txt')
        for linha in f.readLines():
            a += linha.count('A')
            c += linha.count('C')
            g += linha.count('G')
            t += linha.count('T')

        f.close()

        return "as frequências relativas para cada caractere A são : " + a + "as frequências relativas para  C são : " + c + "as frequências relativas para  G são : " + g + "as frequências relativas para  T são : " + t


def frequencia(sequencia):
    f = dict()
    for s in sequencia:
        if not s in f.keys():
            f[s] = sequencia.count(s) / len(sequencia)
            print(s, "\t", "{:.2%}".format(f[s]))
