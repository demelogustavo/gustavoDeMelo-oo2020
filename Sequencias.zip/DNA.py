class DNA():

  def __init__(self, sequencia, chave):
   self.sequencia =sequencia
   self.chave =chave

  def criarchave():
   arq = open('AAs/Codigo.txt')
   chave=dict()
   for linha in arq.readlines():
     nome=""
     for coluna in linha.split("\t"):
       coluna.replace("\n","")
       if not coluna=="":
         if not len(coluna)==3:
           nome=coluna
         else:
           chave[coluna]=nome
          #print(nome," - ", coluna)
   arq.close()
   return chave

  def traduz(sequencia,chave):
   l=False
   traducao=""
   genes=list()
   i=0
   while i < len(sequencia)-3:
     codon=sequencia[i:i+3]
    #print(codon,chave[codon])
     if chave[codon]=="INICIAÇÃO":
       l=True
       i=i+3
       while l==True and i < len(sequencia)-3:
         codon=sequencia[i:i+3]
        #print(codon,chave[codon])
         if chave[codon]=="PARADA":
           l=False
           if not traducao=="":
             genes.append(traducao)
             traducao=""
         elif not chave[codon]=="INICIAÇÃO":
           traducao=traducao+chave[codon]
         i=i+3
      
     else:
       i=i+1  
   return genes