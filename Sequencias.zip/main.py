import Seq
import DNA
import SeqList

def aleatorio(chave):
  import random
  sequencia=""
  lista=list(chave.keys())
  for i in range(100000):
    sequencia=sequencia+random.choice(lista)
  return sequencia

Seq.
chave=DNA.criarchave()
#print(chave)
sequencia = aleatorio(chave)
#print(sequencia)
#Seq.freq(sequencia)
genes=DNA.traduz(sequencia,chave)
for i in range(len(genes)):
  nome="Genes/Gene "+str(i)+".fasta"
  SeqList.gravafasta(nome,genes[i])
